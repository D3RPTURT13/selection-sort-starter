import java.util.ArrayList;
import java.util.Collections;

public class SelectionSorter {
	 public static void selectionSort(ArrayList<String> wordList) {
	    for (int i = 0; i < wordList.size() - 1; ++i) {
	      int minIndex = i;
	      for (int j = i + 1; j < wordList.size(); ++j) {
	        if (wordList.get(i).compareTo(wordList.get(minIndex)) < 0){
	          minIndex = j;
		     // String temp = wordList.get[i];
		      //wordList[i] = wordList[minIndex];
		      //wordList[minIndex] = temp;
		      Collections.swap(wordList,  i,  j);
	    }
	  }
}
	 }
}
